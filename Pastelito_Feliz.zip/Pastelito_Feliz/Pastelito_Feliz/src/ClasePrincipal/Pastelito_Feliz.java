
package ClasePrincipal;
import Vista.Login;

public class Pastelito_Feliz {

    
    public static void main(String[] args) {
        Login lo = new Login();
        lo.setVisible(true);
    }
    
}
